"""Custom Exceptions."""


class HacsException(Exception):
    """Super basic."""
